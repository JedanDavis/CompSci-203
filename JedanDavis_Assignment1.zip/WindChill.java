import java.util.Scanner;

public class WindChill 
{

	public static void main(String[] args) 
	{
	System.out.println("Wind Chill Calculator");
	
	Scanner input = new Scanner(System.in);
	
	
	System.out.print("Enter the temperature in Fahrenheit (must be >= -45 and <= 40): ");
	float Fahrenheit = input.nextFloat();
	
	System.out.print("Enter the wind speed(must be >= 5 and <= 60): ");
	float WindSpeed = input.nextFloat();
	
	float V= (float) Math.pow(WindSpeed,0.16);
	
	float WindchillTemp=(float) (35.74 + (0.6215*Fahrenheit) - (35.75*V) + ((0.4275*Fahrenheit)*V));
	
	System.out.println("\nWind chill temperature: " + WindchillTemp);
	System.out.println("\nProgrammer: Jedan Davis");
	}

}
