import javax.swing.JOptionPane;
import java.util.Random;
import java.text.DecimalFormat;
public class Birthday {
	public static void main (String args[])
	{
		Toy toyobject =new Toy();
		DecimalFormat dollar = new DecimalFormat("#,##0.00");	//format cost

		
        JOptionPane.showMessageDialog(null,"Welcome to the birthday shop!!");

		String name= JOptionPane.showInputDialog("Enter the name of the child");
		
		int Age= Integer.parseInt(JOptionPane.showInputDialog("How old is the child?"));
		toyobject.setAge(Age);

		String Toy= JOptionPane.showInputDialog("Choose a toy: a plushie, blocks or a book");
		toyobject.setToy(Toy);
		
		toyobject.setCost(Toy);
		
		if (toyobject.ageOK()==false)
			
		{
			String choice= JOptionPane.showInputDialog("This toy is not age appropriate. Would you like to cancel the toy request? (Yes or No)");
			
		
		while (choice.toLowerCase().equals("yes"))
			
		{
			 name= JOptionPane.showInputDialog("Enter the name of the child");
			
			 Age= Integer.parseInt(JOptionPane.showInputDialog("How old is the child?"));
			toyobject.setAge(Age);

		    Toy= JOptionPane.showInputDialog("Choose a toy: a plushie, blocks or a book");
			toyobject.setToy(Toy);
			
			toyobject.setCost(Toy);
            choice="No";

		}
		}
		
		
		String card= JOptionPane.showInputDialog("Do you want a card with the gift? Yes or No");
		toyobject.addCard(card);
		String ballon= JOptionPane.showInputDialog("Do you want a balloon with the gift? Yes or No");
		toyobject.addBalloon(ballon);
		
        System.out.println("the gift for " + name + " " + toyobject.toString());
        
        double Total_cost_Firsttoy= toyobject.getCost();

		String input= JOptionPane.showInputDialog("Do you want another toy? Yes or No");
		
		
		
		
		
		 while((input.toLowerCase().equals("yes")))
 
		{			
			 name= JOptionPane.showInputDialog("Enter the name of the child");
			
			Age= Integer.parseInt(JOptionPane.showInputDialog("How old is the child?"));
			toyobject.setAge(Age);

			Toy= JOptionPane.showInputDialog("Choose a toy: a plushie, blocks or a book");
			toyobject.setToy(Toy);
			
			toyobject.setCost(Toy);
			
			if (toyobject.ageOK()==false)
				
			{
				String choice= JOptionPane.showInputDialog("This toy is not age appropriate. Would you like to cancel the toy request? (Yes or No)");
			
			
			while (choice.equals("Yes"))
				
			{
				 name= JOptionPane.showInputDialog("Enter the name of the child");
					
				 Age= Integer.parseInt(JOptionPane.showInputDialog("How old is the child?"));
				toyobject.setAge(Age);

			    Toy= JOptionPane.showInputDialog("Choose a toy: a plushie, blocks or a book");
				toyobject.setToy(Toy);
				
				toyobject.setCost(Toy);
				choice="No";
			}
			}
			 
			
			card= JOptionPane.showInputDialog("Do you want a card with the gift? Yes or No");
			toyobject.addCard(card);
			
			ballon= JOptionPane.showInputDialog("Do you want a balloon with the gift? Yes or No");
			toyobject.addBalloon(ballon);
			
			Total_cost_Firsttoy+=toyobject.getCost();
			
	        System.out.println("The gift for " + name + " " + toyobject.toString());
			 input= JOptionPane.showInputDialog("Do you want another toy? Yes or No");

			
		}
		 
		 
		 Random number= new Random();
         int random_num = 10000 + number.nextInt(100000 - 10000);
         System.out.println("The total cost of your order is $"+ dollar.format(Total_cost_Firsttoy));
         System.out.println("order number is " + random_num);
         System.out.println("Programmer = Jedan Davis");

	}

}
