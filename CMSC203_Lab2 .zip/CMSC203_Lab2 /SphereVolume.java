import java.util.Scanner;
public class SphereVolume {

	public static void main(String[] args) 
	{ 
		double diam;
		
		Scanner input= new Scanner (System.in);
		
		System.out.println("Please enter the diameter of the sphere: ");
		diam=input.nextDouble();
		
		double radius=diam/2;
		double volume=(4*Math.PI*Math.pow(radius, 3))/3;
		
		System.out.println("The Diameter you entered was "+diam+". The riadus is "+radius+". The volume of the sphere is "+volume);
	} 
	} 
